using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlDbEdgeDemo.Web.Options
{
  public class IoTHubOptions
  {
    public string ModuleConnectionString { get; set; }
  }
}
