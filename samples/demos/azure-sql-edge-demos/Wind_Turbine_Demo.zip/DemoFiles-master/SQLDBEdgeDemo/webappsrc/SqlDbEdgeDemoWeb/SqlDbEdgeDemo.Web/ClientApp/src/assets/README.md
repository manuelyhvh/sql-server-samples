# Shared Assets folder

This folder is for shared assets that are imported into components.