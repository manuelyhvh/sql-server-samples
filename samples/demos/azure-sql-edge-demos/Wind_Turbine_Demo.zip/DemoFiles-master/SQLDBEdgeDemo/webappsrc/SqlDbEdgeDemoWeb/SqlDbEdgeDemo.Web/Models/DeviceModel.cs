using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SqlDbEdgeDemo.Web.Models
{
  public class DeviceModel
  {
    public bool Alert { get; set; }
  }
}
